#my_message = "It's Late"
#print(my_message)

#my_message = "Hello World"
#print(my_message)

#my_message = "Hello World, how are you?"
#print(my_message)

#my_text = "She said \"Hello!\""
#print(my_text)


#my_message = 'What\'s your name? Who\'s your daddy?'
#print(my_message)

#Starting the HandsOn for Lesson One
FirstQuestion = "What is your name?"
print(FirstQuestion)

first_answer = 'My name is "Billy"'
print(first_answer)

SecondQuestion = "How old are you?"
print(SecondQuestion)

second_answer = 30
print(second_answer)

#ThirdQuestion = "How many months is that?"
#print(ThirdQuestion)

#third_answer = 360
#print(third_answer)

my_string = "Hey, this is a string!"

my_integer = -14

my_float = 15/7

print(my_string)
print(my_integer)
print(my_float)
