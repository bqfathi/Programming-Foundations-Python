def sum_function

#I've run out of time this week and will come back to look at all of this later
